#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HDU selection helpers for FITS files.

This module centralizes HDU selection semantics used throughout ``fits_tools``.
Public APIs should prefer the ``hdu`` parameter name and the ``HDUSelector``
type defined here rather than exposing ad hoc combinations of ``ext``,
``fits_ext``, or raw integer-only interfaces.
"""

from pathlib import Path
from typing import Literal

from astropy.io import fits
from astropy.io.fits.hdu.base import ExtensionHDU

from .exceptions import (
    FileHandlingError,
    InvalidHDUIndexError,
    InvalidParameterError,
)
from .types import StrOrPath

HDUSelector = int | str | tuple[str, int] | Literal["auto"]
AutoHDU = Literal["primary", "first_image", "first_sci_image"]

__all__ = [
    "AutoHDU",
    "HDUSelector",
    "is_image_like_hdu",
    "resolve_hdu_index",
    "resolve_hdu_index_in_file",
]


def is_image_like_hdu(hdu: ExtensionHDU) -> bool:
    """Return True if *hdu* is an image HDU with a non-trivial image shape.

    The check is header-based and does not require materializing ``.data``.
    This avoids unnecessary decompression or array allocation during
    header-only workflows.
    """
    if not isinstance(hdu, (fits.PrimaryHDU, fits.ImageHDU, fits.CompImageHDU)):
        return False

    try:
        naxis = int(hdu.header.get("NAXIS", 0) or 0)
        naxis1 = int(hdu.header.get("NAXIS1", 0) or 0)
        naxis2 = int(hdu.header.get("NAXIS2", 0) or 0)
    except Exception:
        return False

    return naxis >= 2 and naxis1 > 0 and naxis2 > 0


def _extname_upper(hdu: ExtensionHDU) -> str:
    """Return normalized EXTNAME for *hdu* (missing -> empty string)."""
    return str(hdu.header.get("EXTNAME", "")).strip().upper()


def _extver_int(hdu: ExtensionHDU) -> int | None:
    """Return integer EXTVER for *hdu*, or None if unavailable/unparseable."""
    extver = hdu.header.get("EXTVER")
    if extver is None:
        return None
    try:
        return int(extver)
    except Exception:
        return None


def _selection_error(
    message: str,
    *,
    parameter: str = "hdu",
    value: object = None,
) -> InvalidParameterError:
    """Create a consistent selector-resolution exception."""
    return InvalidParameterError(message, parameter=parameter, value=value)


def resolve_hdu_index(
    hdul: fits.HDUList,
    hdu: HDUSelector = "auto",
    *,
    auto: AutoHDU = "primary",
    image_like: bool = False,
    require_data: bool = False,
    filepath: StrOrPath | None = None,
) -> int:
    """Resolve an HDU selector to an integer index.

    Parameters
    ----------
    hdul
        Already-open FITS HDU list.
    hdu
        HDU selector. Supported forms are:

        - ``int``: zero-based HDU index
        - ``str``: case-insensitive ``EXTNAME`` (non-empty)
        - ``(str, int)``: ``(EXTNAME, EXTVER)`` (EXTNAME must be non-empty)
        - ``"auto"``: resolve according to *auto*
    auto
        Policy used when ``hdu="auto"``.
    image_like
        If True, require the selected HDU to be image-like by header inspection.
    require_data
        If True, require the selected HDU to have non-None ``.data``.
        This may force decompression for compressed image HDUs.
    filepath
        Optional file path used only to improve exception messages.

    Returns
    -------
    int
        Resolved HDU index.

    Raises
    ------
    InvalidHDUIndexError
        If an integer selector is out of bounds.
    InvalidParameterError
        If the selector is malformed, ambiguous, or does not satisfy the
        requested constraints.
    """

    def meets_constraints(index: int) -> bool:
        candidate = hdul[index]
        if image_like and not is_image_like_hdu(candidate):
            return False
        if require_data and candidate.data is None:
            return False
        return True

    if isinstance(hdu, int):
        if hdu < 0 or hdu >= len(hdul):
            raise InvalidHDUIndexError(filepath or "<memory>", hdu, len(hdul))
        if not meets_constraints(hdu):
            raise _selection_error(
                "HDU does not satisfy the requested selection constraints.",
                value=hdu,
            )
        return hdu

    if isinstance(hdu, tuple):
        if len(hdu) != 2:
            raise _selection_error(
                "Tuple HDU selector must be of the form (EXTNAME, EXTVER).",
                value=hdu,
            )

        extname, extver = hdu
        target_name = str(extname).strip().upper()
        if not target_name:
            raise _selection_error("EXTNAME must be a non-empty string.", value=hdu)

        try:
            target_ver = int(extver)
        except Exception as exc:
            raise _selection_error("EXTVER must be an integer.", value=hdu) from exc

        matches = [
            index
            for index, candidate in enumerate(hdul)
            if _extname_upper(candidate) == target_name
            and _extver_int(candidate) == target_ver
            and meets_constraints(index)
        ]

        if not matches:
            raise _selection_error(
                f"No HDU matches selector (EXTNAME={target_name!r}, EXTVER={target_ver}).",
                value=hdu,
            )
        if len(matches) > 1:
            raise _selection_error(
                f"Ambiguous HDU selector (EXTNAME={target_name!r}, EXTVER={target_ver}); "
                f"matched HDUs {matches}.",
                value=hdu,
            )
        return matches[0]

    if isinstance(hdu, str) and hdu != "auto":
        target_name = hdu.strip().upper()
        if not target_name:
            raise _selection_error("EXTNAME selector must be a non-empty string.", value=hdu)

        matches = [
            index
            for index, candidate in enumerate(hdul)
            if _extname_upper(candidate) == target_name and meets_constraints(index)
        ]

        if not matches:
            raise _selection_error(
                f"No HDU with EXTNAME={hdu!r} satisfies the requested constraints.",
                value=hdu,
            )
        if len(matches) > 1:
            versions = [(_extver_int(hdul[index]), index) for index in matches]
            raise _selection_error(
                f"Ambiguous EXTNAME selector {hdu!r}; matched HDUs {versions}. "
                "Use (EXTNAME, EXTVER) to disambiguate.",
                value=hdu,
            )
        return matches[0]

    if hdu != "auto":
        raise _selection_error(
            "hdu must be an integer, EXTNAME string, (EXTNAME, EXTVER) tuple, or 'auto'.",
            value=hdu,
        )

    if auto == "primary":
        if len(hdul) == 0:
            raise _selection_error("Cannot resolve 'primary' from an empty HDUList.", value=hdu)
        if not meets_constraints(0):
            raise _selection_error(
                "Primary HDU does not satisfy the requested selection constraints.",
                value=hdu,
            )
        return 0

    if auto == "first_sci_image":
        preferred_extnames = {"SCI", "IMAGE"}
        for index, candidate in enumerate(hdul):
            if _extname_upper(candidate) in preferred_extnames and meets_constraints(index):
                return index
        auto = "first_image"

    if auto == "first_image":
        for index in range(len(hdul)):
            if meets_constraints(index):
                return index
        raise _selection_error(
            "No HDU satisfies the requested selection constraints.",
            parameter="auto",
            value=auto,
        )

    raise _selection_error(
        f"Unknown auto-selection policy {auto!r}.",
        parameter="auto",
        value=auto,
    )


def resolve_hdu_index_in_file(
    filepath: StrOrPath,
    hdu: HDUSelector = "auto",
    *,
    auto: AutoHDU = "primary",
    image_like: bool = False,
    require_data: bool = False,
    memmap: bool = True,
) -> int:
    """Open a FITS file and resolve *hdu* to an integer index."""
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileHandlingError(f"File not found: {filepath}", filepath=filepath)

    try:
        with fits.open(filepath, memmap=memmap, mode="readonly") as hdul:
            return resolve_hdu_index(
                hdul,
                hdu,
                auto=auto,
                image_like=image_like,
                require_data=require_data,
                filepath=filepath,
            )
    except (FileHandlingError, InvalidHDUIndexError, InvalidParameterError):
        raise
    except Exception as exc:
        raise FileHandlingError(
            f"Failed to open/read FITS file {filepath}: {exc}",
            filepath=filepath,
        ) from exc