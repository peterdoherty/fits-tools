#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Image combining and stacking operations.

This module provides robust image combining functionality for creating master
calibration frames and stacking science images. It supports multiple combining
methods with outlier rejection, weighted combining, and memory-efficient
streaming for large datasets.

Primary Functions:
    - combine_images_robust(): Modern API with sigma-clipping and robust statistics
    - combine_images(): Legacy API for backward compatibility
    - median_combine(): Convenience wrapper for median stacking
    - mean_combine(): Convenience wrapper for mean stacking
    - create_master_frame(): Specialized for calibration frame creation

Combining Methods:
    - 'sigma_clipped_median': Iterative sigma-clipped median (recommended)
    - 'sigma_clipped_mean': Iterative sigma-clipped mean
    - 'median': Simple median (no outlier rejection)
    - 'mean': Simple mean (no outlier rejection)
    - 'weighted_mean': Weighted average (requires weights)

Features:
    - Outlier rejection with sigma-clipping
    - Weighted combining (by exposure time, SNR, etc.)
    - Mask support for bad pixels
    - Memory-efficient processing (v2.1.0: 50% reduction in peak memory)
    - Automatic exposure time normalization
    - Quality metrics and statistics
    - Progress reporting

References
----------
.. [1] Sigma-clipping algorithm as implemented in astropy.stats.sigma_clip
    https://docs.astropy.org/en/stable/api/astropy.stats.sigma_clip.html

Version: 2.1.0

Changes in 2.1.0:
    - Optimized memory usage: pre-allocate stacked array instead of
      intermediate list. Reduces peak memory by ~50% for file-based combining.
    - Added memory usage logging.
"""

import logging
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
from astropy.io import fits
from astropy.stats import mad_std, sigma_clip, sigma_clipped_stats

# Optional dependencies
try:
    from tqdm import tqdm as _tqdm
except ImportError:
    _tqdm = None

from ..array_utils import validate_shapes
from ..constants import FITS_KEY_EXPTIME
from ..exceptions import ImageProcessingError, SelectionError
from ..io import get_data, get_data_and_header, get_header, write_simple_fits
from ..selection import select_files
from ..types import StrOrPath
from ..utils import add_history
from .result_types import CombiningResult

logger = logging.getLogger(__name__)


# ============================================================================
# Utility Functions
# ============================================================================

def _load_and_stack_efficient(
    input_param: Union[str, List[str], List[np.ndarray]],
    hdu: int = 0,
    keys: Optional[Dict[str, Any]] = None,
    working_dtype: np.dtype = np.float64,
    recursive: bool = False,
) -> Tuple[np.ndarray, List[str], fits.Header]:
    """
    Load and stack images directly into a pre-allocated array.

    This function avoids creating an intermediate list of arrays, reducing
    peak memory usage by approximately 50% compared to the load-then-stack
    approach **when loading from files**. For pre-loaded NumPy arrays, no
    memory benefit is gained as the arrays must be stacked regardless.

    Parameters
    ----------
    input_param : str, list of str, or list of np.ndarray
        Input specification:

        - Directory path (searches for FITS files)
        - List of file paths
        - List of NumPy arrays (in-memory; no memory benefit)
    hdu : int, optional
        HDU extension to load. Default: 0.
    keys : dict, optional
        Header keyword filters for file selection.
    working_dtype : np.dtype, optional
        Dtype for the stacked output array. Applied to both file-based and
        in-memory paths for consistent downstream arithmetic. Default: float64.
    recursive : bool, optional
        Recursive directory search. Default: False.

    Returns
    -------
    tuple
        ``(stacked_array, file_list, base_header)`` where:

        - ``stacked_array``: 3D array with shape ``(N, rows, cols)``
        - ``file_list``: list of file paths (empty for in-memory arrays)
        - ``base_header``: FITS header from first file/array

    Raises
    ------
    ImageProcessingError
        If no valid data can be loaded or files are not found.
    """
    base_header = fits.Header()

    # Case 1: Pre-loaded NumPy arrays
    if isinstance(input_param, list) and all(
        isinstance(i, np.ndarray) for i in input_param
    ):
        logger.debug("Processing %d in-memory arrays", len(input_param))

        validate_shapes(*input_param, operation="combining")

        try:
            # Cast to working_dtype for consistency with the file-loading path
            stacked = np.stack(input_param, axis=0).astype(working_dtype)
        except ValueError as e:
            raise ImageProcessingError(
                f"Failed to stack images — dimension mismatch: {e}"
            ) from e

        add_history(
            base_header, f"Combined from {len(input_param)} in-memory arrays"
        )
        return stacked, [], base_header

    # Case 2: Load from files (memory-efficient path)
    if isinstance(input_param, str):
        try:
            file_list = select_files(
                input_param,
                keys=keys,
                recursive=recursive,
            )
        except SelectionError as e:
            raise ImageProcessingError(f"File selection failed: {e}") from e
    else:
        file_list = [Path(f) for f in input_param]

    if not file_list:
        raise ImageProcessingError("No files found for combining")

    n_files = len(file_list)
    logger.debug("Loading %d files for combining", n_files)

    # Get shape and dtype from first file
    first_data = get_data(file_list[0], hdu=hdu)
    if first_data is None:
        raise ImageProcessingError(
            f"Could not load first file: {file_list[0]}"
        )

    shape = first_data.shape

    # Log memory requirement before allocating
    bytes_per_element = np.dtype(working_dtype).itemsize
    total_bytes = n_files * shape[0] * shape[1] * bytes_per_element
    total_gb = total_bytes / (1024 ** 3)
    total_mb = total_bytes / (1024 ** 2)

    if total_gb >= 1.0:
        logger.debug(
            "Memory requirement: %.2f GB for %d × %s images",
            total_gb, n_files, shape,
        )
        if total_gb >= 4.0:
            logger.warning(
                "Large memory allocation (%.2f GB). Ensure sufficient RAM.",
                total_gb,
            )
    else:
        logger.debug(
            "Memory requirement: %.1f MB for %d × %s images",
            total_mb, n_files, shape,
        )

    # Pre-allocate 3D array (avoids intermediate list)
    try:
        stacked = np.zeros((n_files, shape[0], shape[1]), dtype=working_dtype)
    except MemoryError as exc:
        raise ImageProcessingError(
            f"Insufficient memory to allocate array for {n_files} images "
            f"({total_gb:.2f} GB required). Consider processing fewer images."
        ) from exc

    # Load first image (already in memory)
    stacked[0] = first_data
    valid_count = 1

    # Load remaining images directly into pre-allocated slots
    for i, filepath in enumerate(file_list[1:], start=1):
        try:
            data = get_data(filepath, hdu=hdu)

            if data is None:
                logger.warning("No data in %s; skipping.", filepath)
                continue

            if data.shape != shape:
                logger.warning(
                    "Shape mismatch in %s: %s vs %s; skipping.",
                    filepath, data.shape, shape,
                )
                continue

            stacked[valid_count] = data
            valid_count += 1

        except Exception as e:
            logger.warning("Failed to load %s: %s", filepath, e)

    if valid_count < n_files:
        logger.debug(
            "Successfully loaded %d/%d files", valid_count, n_files
        )
        stacked = stacked[:valid_count]

    if valid_count == 0:
        raise ImageProcessingError(
            "No valid data could be loaded from files"
        )

    # Header from first file
    try:
        base_header = get_header(file_list[0], hdu=hdu)
    except Exception as e:
        logger.warning("Could not load header from %s: %s", file_list[0], e)

    add_history(base_header, f"Combined from {valid_count} files")

    return stacked, file_list[:valid_count], base_header


def _apply_mask(
    stacked_data: np.ndarray,
    mask: Optional[np.ndarray],
) -> np.ndarray:
    """
    Apply a bad pixel mask to stacked data.

    The mask is broadcast across all images in the stack. Masked pixels
    are excluded from subsequent combining operations.

    Parameters
    ----------
    stacked_data : np.ndarray
        Stacked images with shape ``(N, rows, cols)``.
    mask : np.ndarray or None
        Boolean mask where True indicates bad pixels to exclude.
        Must have shape ``(rows, cols)``. If None, returns data unchanged.

    Returns
    -------
    np.ndarray or np.ma.MaskedArray
        If *mask* is None, returns the original *stacked_data* unmodified.
        Otherwise returns a MaskedArray with the mask applied to all images.

    Raises
    ------
    ImageProcessingError
        If mask shape does not match image dimensions.
    """
    if mask is None:
        return stacked_data

    if mask.shape != stacked_data.shape[1:]:
        raise ImageProcessingError(
            f"Mask shape {mask.shape} does not match image shape "
            f"{stacked_data.shape[1:]}"
        )

    mask_3d = np.broadcast_to(mask, stacked_data.shape)
    return np.ma.masked_array(stacked_data, mask=mask_3d)


# ============================================================================
# Combining Methods
# ============================================================================

def _combine_sigma_clipped_median(
    stacked_data: np.ndarray,
    sigma: float = 3.0,
    maxiters: int = 5,
    fill_value: float = 0.0,
) -> Tuple[np.ndarray, int]:
    """
    Combine using sigma-clipped median.

    Parameters
    ----------
    stacked_data : np.ndarray
        Stacked images ``(N, rows, cols)``.
    sigma : float
        Sigma threshold for clipping.
    maxiters : int
        Maximum clipping iterations.
    fill_value : float
        Value used to fill any residual masked pixels.

    Returns
    -------
    (combined_array, num_clipped_pixels)
    """
    logger.debug(
        "Sigma-clipped median: sigma=%.2f, maxiters=%d", sigma, maxiters
    )

    clipped = sigma_clip(stacked_data, sigma=sigma, maxiters=maxiters, axis=0)
    combined = np.ma.median(clipped, axis=0)

    num_clipped = int(np.sum(clipped.mask)) if hasattr(clipped, "mask") else 0

    if isinstance(combined, np.ma.MaskedArray):
        combined = combined.filled(fill_value)

    return combined, num_clipped


def _combine_sigma_clipped_mean(
    stacked_data: np.ndarray,
    sigma: float = 3.0,
    maxiters: int = 5,
    fill_value: float = 0.0,
) -> Tuple[np.ndarray, int]:
    """
    Combine using sigma-clipped mean.

    Parameters
    ----------
    stacked_data : np.ndarray
        Stacked images ``(N, rows, cols)``.
    sigma : float
        Sigma threshold for clipping.
    maxiters : int
        Maximum clipping iterations.
    fill_value : float
        Value used to fill any residual masked pixels.

    Returns
    -------
    (combined_array, num_clipped_pixels)
    """
    logger.debug(
        "Sigma-clipped mean: sigma=%.2f, maxiters=%d", sigma, maxiters
    )

    clipped = sigma_clip(stacked_data, sigma=sigma, maxiters=maxiters, axis=0)
    combined = np.ma.mean(clipped, axis=0)

    num_clipped = int(np.sum(clipped.mask)) if hasattr(clipped, "mask") else 0

    if isinstance(combined, np.ma.MaskedArray):
        combined = combined.filled(fill_value)

    return combined, num_clipped


def _combine_median(
    stacked_data: np.ndarray,
) -> Tuple[np.ndarray, int]:
    """
    Combine using simple median (no outlier rejection).

    Parameters
    ----------
    stacked_data : np.ndarray
        Stacked images ``(N, rows, cols)``.

    Returns
    -------
    (combined_array, 0)
    """
    logger.debug("Simple median combine (no clipping)")
    return np.median(stacked_data, axis=0), 0


def _combine_mean(
    stacked_data: np.ndarray,
    weights: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, int]:
    """
    Combine using mean or weighted mean.

    Parameters
    ----------
    stacked_data : np.ndarray
        Stacked images ``(N, rows, cols)``.
    weights : np.ndarray, optional
        Per-image weights with shape ``(N,)``.

    Returns
    -------
    (combined_array, 0)
    """
    if weights is not None:
        logger.debug(
            "Weighted mean combine (weights shape: %s)", weights.shape
        )

        if len(weights) != stacked_data.shape[0]:
            raise ImageProcessingError(
                f"Number of weights ({len(weights)}) does not match "
                f"number of images ({stacked_data.shape[0]})"
            )

        combined = np.average(stacked_data, axis=0, weights=weights)
    else:
        logger.debug("Simple mean combine (no weighting)")
        combined = np.mean(stacked_data, axis=0)

    return combined, 0


# ============================================================================
# Main Combining Functions
# ============================================================================

def combine_images_robust(
    input_param: Union[str, List[str], List[np.ndarray]],
    method: str = "sigma_clipped_median",
    sigma: float = 3.0,
    maxiters: int = 5,
    mask: Optional[np.ndarray] = None,
    weights: Optional[Union[List[float], np.ndarray, str]] = None,
    output_file: Optional[str] = None,
    hdu: int = 0,
    keys: Optional[Dict[str, Any]] = None,
    working_dtype: np.dtype = np.float64,
    recursive: bool = False,
    overwrite: bool = False,
    return_type: str = "auto",
) -> Union[np.ndarray, str, CombiningResult]:
    """
    Combine multiple images using robust statistics with outlier rejection.

    This is the primary combining function with support for multiple methods,
    masking, weighting, and automatic outlier rejection. Suitable for creating
    master calibration frames and stacking science images.

    Memory-efficient in v2.1.0: Peak memory reduced by ~50% for file-based
    combining through direct loading into a pre-allocated array.

    Parameters
    ----------
    input_param : str, list of str, or list of np.ndarray
        Input images. Can be:

        - Directory path (will search for FITS files)
        - List of file paths
        - List of NumPy arrays (in-memory)
    method : str, optional
        Combining method:

        - ``'sigma_clipped_median'``: Iterative sigma-clipped median
          (default; recommended for calibration frames)
        - ``'sigma_clipped_mean'``: Iterative sigma-clipped mean
        - ``'median'``: Simple median (no outlier rejection)
        - ``'mean'``: Simple mean (no outlier rejection)
        - ``'weighted_mean'``: Weighted mean (requires *weights* parameter)
    sigma : float, optional
        Sigma threshold for clipping. Default: 3.0.
    maxiters : int, optional
        Maximum clipping iterations. Default: 5.
    mask : np.ndarray, optional
        Boolean mask array (True = bad pixels to exclude). Must match
        image shape.
    weights : list, np.ndarray, or str, optional
        Weights for each image (for ``weighted_mean`` method).
        ``'exptime'`` uses exposure times from FITS headers.
        ``'inverse_variance'`` uses 1/variance as weights.
    output_file : str, optional
        Output FITS file path. If None, returns an in-memory result.
    hdu : int, optional
        HDU extension to process. Default: 0.
    keys : dict, optional
        Header keyword filters for file selection
        (e.g., ``{'IMAGETYP': 'BIAS'}``).
    working_dtype : np.dtype, optional
        Dtype for internal arithmetic. Default: float64.
    recursive : bool, optional
        Recursively search directories. Default: False.
    overwrite : bool, optional
        Overwrite existing output file. Default: False.
    return_type : str, optional
        Return type: ``'array'``, ``'path'``, ``'result'``, or ``'auto'``.
        ``'auto'`` returns :class:`CombiningResult` if *output_file* is
        None, else the output path string.

    Returns
    -------
    np.ndarray, str, or CombiningResult
        Type depends on *output_file* and *return_type*.

    Raises
    ------
    ImageProcessingError
        If combining fails due to shape mismatch, invalid parameters, etc.

    Notes
    -----
    - For calibration frames, ``'sigma_clipped_median'`` is recommended.
    - Memory usage (v2.1.0): ~N × image_size (reduced from ~2N in v2.0.0).
    - For very large datasets (>10 GB), monitor available system memory.

    Examples
    --------
    Combine bias frames with sigma-clipping:

    >>> bias_files = ['bias_001.fits', 'bias_002.fits', 'bias_003.fits']
    >>> master_bias = combine_images_robust(
    ...     bias_files,
    ...     method='sigma_clipped_median',
    ...     sigma=3.0,
    ...     output_file='master_bias.fits',
    ... )

    Combine in-memory arrays:

    >>> import numpy as np
    >>> arrays = [np.random.normal(100, 10, (512, 512)) for _ in range(10)]
    >>> result = combine_images_robust(arrays, method='median')
    >>> print(result.data.shape)
    (512, 512)
    """
    valid_methods = (
        "sigma_clipped_median",
        "sigma_clipped_mean",
        "median",
        "mean",
        "weighted_mean",
    )
    if method not in valid_methods:
        raise ValueError(
            f"Unknown combining method: '{method}'. "
            f"Valid options: {', '.join(valid_methods)}"
        )

    if sigma <= 0:
        raise ValueError(f"sigma must be positive, got {sigma}")
    if maxiters < 1:
        raise ValueError(f"maxiters must be >= 1, got {maxiters}")

    stacked_data, file_list, base_header = _load_and_stack_efficient(
        input_param,
        hdu=hdu,
        keys=keys,
        working_dtype=working_dtype,
        recursive=recursive,
    )

    num_images = stacked_data.shape[0]
    logger.debug(
        "Combining %d images using method: %s", num_images, method
    )
    logger.debug("Stacked data shape: %s", stacked_data.shape)

    if mask is not None:
        stacked_data = _apply_mask(stacked_data, mask)

    # Resolve weights
    weights_array = None
    if weights is not None:
        if isinstance(weights, str):
            if weights == "exptime":
                if not file_list:
                    raise ImageProcessingError(
                        "Cannot use 'exptime' weights with in-memory arrays"
                    )
                exp_weights = []
                for filepath in file_list:
                    hdr = get_header(filepath, hdu=hdu)
                    exptime = hdr.get(FITS_KEY_EXPTIME)
                    if exptime is None:
                        raise ImageProcessingError(
                            f"No {FITS_KEY_EXPTIME} keyword in {filepath}"
                        )
                    exp_weights.append(float(exptime))
                weights_array = np.array(exp_weights)
                logger.debug(
                    "Using exposure time weights: min=%.2f, max=%.2f, n=%d",
                    weights_array.min(),
                    weights_array.max(),
                    len(weights_array),
                )

            elif weights == "inverse_variance":
                variances = np.array([
                    np.ma.var(stacked_data[i])
                    for i in range(stacked_data.shape[0])
                ])
                if np.any(variances <= 0):
                    logger.warning(
                        "Non-positive variances encountered; "
                        "clamping to minimum value 1e-12"
                    )
                    variances = np.clip(variances, 1e-12, None)
                weights_array = 1.0 / variances
                logger.debug(
                    "Using inverse variance weights: min=%.4e, max=%.4e",
                    weights_array.min(),
                    weights_array.max(),
                )

            else:
                raise ValueError(
                    f"Unknown weight type: '{weights}'. "
                    "Use 'exptime', 'inverse_variance', or provide explicit "
                    "weights as an array."
                )
        else:
            weights_array = np.asarray(weights)

    # Perform combining
    if method == "sigma_clipped_median":
        combined, num_clipped = _combine_sigma_clipped_median(
            stacked_data, sigma=sigma, maxiters=maxiters
        )
    elif method == "sigma_clipped_mean":
        combined, num_clipped = _combine_sigma_clipped_mean(
            stacked_data, sigma=sigma, maxiters=maxiters
        )
    elif method == "median":
        combined, num_clipped = _combine_median(stacked_data)
    elif method in ("mean", "weighted_mean"):
        combined, num_clipped = _combine_mean(
            stacked_data, weights=weights_array
        )
    else:  # pragma: no cover — validated above
        raise ValueError(f"Unhandled method: '{method}'")

    total_pixels = stacked_data.shape[0] * stacked_data.shape[1] * stacked_data.shape[2]
    clip_fraction = num_clipped / total_pixels if total_pixels > 0 else 0.0

    if num_clipped > 0:
        logger.debug(
            "Clipped %d pixels (%.2f%%)", num_clipped, clip_fraction * 100
        )

    # Build output header
    new_header = base_header.copy()
    add_history(new_header, f"Combined {num_images} images using {method}")
    new_header["NCOMBINE"] = (num_images, "Number of images combined")
    new_header["COMBMETH"] = (method, "Combining method")

    if method.startswith("sigma_clipped"):
        new_header["SIGMA"] = (sigma, "Sigma threshold for clipping")
        new_header["MAXITERS"] = (maxiters, "Maximum clipping iterations")
        new_header["NCLIPPED"] = (num_clipped, "Number of clipped pixels")

    if weights_array is not None:
        new_header["WEIGHTED"] = (True, "Weighted combining used")
        if isinstance(weights, str):
            new_header["WEIGHTBY"] = (weights, "Weighting method")

    result = CombiningResult(
        data=combined,
        header=new_header,
        method=method,
        num_images=num_images,
        num_clipped=num_clipped,
        clip_fraction=clip_fraction,
        input_files=file_list if file_list else None,
        output_file=output_file,
    )

    if output_file is not None:
        write_simple_fits(output_file, combined, new_header, overwrite=overwrite)
        logger.debug("Combined image written to: %s", output_file)

    if return_type == "array":
        return combined
    elif return_type == "path":
        if output_file is None:
            raise ValueError(
                "return_type='path' requires output_file to be specified"
            )
        return output_file
    elif return_type in ("result", "auto"):
        return result
    else:
        raise ValueError(
            f"Invalid return_type: '{return_type}'. "
            "Must be 'array', 'path', 'result', or 'auto'."
        )


# ============================================================================
# Specialized Combining Functions
# ============================================================================

def create_master_frame(
    frame_list: Union[str, List[str], List[np.ndarray]],
    frame_type: str,
    method: str = "sigma_clipped_median",
    normalize: bool = False,
    working_dtype: np.dtype = np.float64,
    return_type: str = "auto",
    **kwargs,
) -> Union[np.ndarray, str, CombiningResult]:
    """
    Create a master calibration frame from multiple exposures.

    Convenience wrapper around :func:`combine_images_robust` specifically
    designed for bias, dark, and flat calibration frames.

    Parameters
    ----------
    frame_list : str, list of str, or list of np.ndarray
        Input calibration frames.
    frame_type : str
        Type of calibration frame: ``'bias'``, ``'dark'``, or ``'flat'``.
    method : str, optional
        Combining method. Default: ``'sigma_clipped_median'``.
    normalize : bool, optional
        If True, divide the result by its median. Default: False.
        Typically used for flat frames. A warning is emitted if
        *normalize* is True but the median is zero.
    working_dtype : np.dtype, optional
        Dtype for internal arithmetic. Default: float64.
    return_type : str, optional
        ``'array'``, ``'path'``, ``'result'``, or ``'auto'``.
    **kwargs
        Additional arguments passed to :func:`combine_images_robust`,
        including ``output_file``, ``hdu``, ``overwrite``, etc.

    Returns
    -------
    np.ndarray, str, or CombiningResult
        Type depends on *return_type* and ``output_file`` in *kwargs*.

    Raises
    ------
    ValueError
        If *frame_type* is not recognised.

    Examples
    --------
    Create master bias:

    >>> master_bias = create_master_frame(
    ...     ['bias_001.fits', 'bias_002.fits'],
    ...     frame_type='bias',
    ...     output_file='master_bias.fits',
    ... )

    Create normalized master flat:

    >>> master_flat = create_master_frame(
    ...     ['flat_001.fits', 'flat_002.fits'],
    ...     frame_type='flat',
    ...     normalize=True,
    ...     output_file='master_flat.fits',
    ... )
    """
    valid_types = ("bias", "dark", "flat")
    if frame_type.lower() not in valid_types:
        raise ValueError(
            f"Unknown frame_type: '{frame_type}'. "
            f"Valid options: {', '.join(valid_types)}"
        )

    result = combine_images_robust(
        frame_list,
        method=method,
        working_dtype=working_dtype,
        return_type="result",
        **kwargs,
    )

    add_history(result.header, f"Master {frame_type.lower()} frame created")
    result.header["FRMTYPE"] = (frame_type.lower(), "Calibration frame type")

    if normalize:
        median_val = float(np.median(result.data))
        if median_val == 0.0:
            logger.warning(
                "Cannot normalize %s frame: median is zero.", frame_type
            )
        else:
            result.data = result.data / median_val
            add_history(
                result.header, f"Normalized by median ({median_val:.4f})"
            )
            result.header["NORMLIZD"] = (True, "Frame has been normalized")
            result.header["NORMVAL"] = (
                median_val, "Normalization value (median)"
            )
            logger.debug(
                "Frame normalized by median %.4f", median_val
            )

            # Re-write output file with normalized data. The file was just
            # created by combine_images_robust; overwrite=True is always
            # correct here since we are updating content we just wrote.
            if result.output_file is not None:
                write_simple_fits(
                    result.output_file,
                    result.data,
                    result.header,
                    overwrite=True,
                )

    if return_type == "array":
        return result.data
    elif return_type == "path":
        if result.output_file is None:
            raise ValueError(
                "return_type='path' requires output_file to be specified "
                "in kwargs"
            )
        return result.output_file
    elif return_type in ("result", "auto"):
        return result
    else:
        raise ValueError(
            f"Invalid return_type: '{return_type}'. "
            "Must be 'array', 'path', 'result', or 'auto'."
        )


# ============================================================================
# Convenience Wrappers
# ============================================================================

def median_combine(
    input_param: Union[str, List[str], List[np.ndarray]],
    filebase: Optional[StrOrPath] = None,
    **kwargs,
) -> Union[np.ndarray, Path]:
    """
    Combine images using sigma-clipped median.

    Convenience wrapper around :func:`combine_images_robust` with
    ``method='sigma_clipped_median'``.

    Parameters
    ----------
    input_param : str, list of str, or list of np.ndarray
        Input images.
    filebase : str or Path, optional
        Output file base name (the ``.fits`` extension is appended
        automatically if absent).
    **kwargs
        Additional arguments passed to :func:`combine_images_robust`.

    Returns
    -------
    np.ndarray or Path
        Combined array if *filebase* is None, otherwise the output path.

    Examples
    --------
    >>> bias_files = ['bias_001.fits', 'bias_002.fits', 'bias_003.fits']
    >>> master_bias = median_combine(bias_files, filebase='master_bias')
    """
    output_file = None
    if filebase is not None:
        filebase = Path(filebase)
        output_file = (
            filebase if filebase.suffix == ".fits"
            else filebase.with_suffix(".fits")
        )

    return combine_images_robust(
        input_param,
        method="sigma_clipped_median",
        output_file=output_file,
        return_type="array" if output_file is None else "path",
        **kwargs,
    )


def mean_combine(
    input_param: Union[str, List[str], List[np.ndarray]],
    filebase: Optional[StrOrPath] = None,
    **kwargs,
) -> Union[np.ndarray, Path]:
    """
    Combine images using sigma-clipped mean.

    Convenience wrapper around :func:`combine_images_robust` with
    ``method='sigma_clipped_mean'``.

    Parameters
    ----------
    input_param : str, list of str, or list of np.ndarray
        Input images.
    filebase : str or Path, optional
        Output file base name (the ``.fits`` extension is appended
        automatically if absent).
    **kwargs
        Additional arguments passed to :func:`combine_images_robust`.

    Returns
    -------
    np.ndarray or Path
        Combined array if *filebase* is None, otherwise the output path.

    Examples
    --------
    >>> dark_files = ['dark_001.fits', 'dark_002.fits', 'dark_003.fits']
    >>> master_dark = mean_combine(dark_files, filebase='master_dark')
    """
    output_file = None
    if filebase is not None:
        filebase = Path(filebase)
        output_file = (
            filebase if filebase.suffix == ".fits"
            else filebase.with_suffix(".fits")
        )

    return combine_images_robust(
        input_param,
        method="sigma_clipped_mean",
        output_file=output_file,
        return_type="array" if output_file is None else "path",
        **kwargs,
    )


# ============================================================================
# Legacy API (Backward Compatibility)
# ============================================================================

def combine_images(
    input_param: Union[str, List[str], List[np.ndarray]],
    operations: Union[str, List[str]],
    filebase: Optional[StrOrPath] = None,
    working_dtype: np.dtype = np.float64,
    **kwargs,
) -> Optional[Union[str, np.ndarray, Dict[str, str], Dict[str, np.ndarray]]]:
    """
    Combine FITS images or NumPy arrays using median or mean stacking.

    .. deprecated:: 2.0.0
        Use :func:`combine_images_robust` for new code, which provides
        better outlier rejection and more combining options.

    Parameters
    ----------
    input_param : str, list of str, or list of np.ndarray
        Input images.
    operations : str or list of str
        Combining operation(s): ``'median'`` or ``'mean'`` (or a list of
        both).
    filebase : str or Path, optional
        Base name for output files. If None, returns in-memory results.
    **kwargs
        Additional arguments:

        - ``hdu`` : int — HDU extension (default: 0). The legacy keyword
          ``ext`` is also accepted for backward compatibility but is
          deprecated.
        - ``overwrite`` : bool — overwrite existing files (default: False)
        - ``output_dir`` : str — output directory
        - ``header`` : fits.Header — template header
        - ``keys`` : dict — header keyword filters
        - ``recursive`` : bool — recursive directory search
        - ``max_files`` : int — maximum number of files to process

    Returns
    -------
    str, np.ndarray, dict, or None
        - Single operation, filebase given: output path (str)
        - Multiple operations, filebase given: ``{op: path}``
        - Single operation, no filebase: array
        - Multiple operations, no filebase: ``{op: array}``
        - Returns None if no files found or processing failed.

    Notes
    -----
    This function does not perform outlier rejection. For robust combining
    with sigma-clipping, use :func:`combine_images_robust`.

    Examples
    --------
    >>> arrays = [np.ones((10, 10)) * i for i in range(1, 6)]
    >>> result = combine_images(arrays, 'median')
    >>> result[5, 5]
    3.0
    """
    warnings.warn(
        "combine_images() is deprecated and will be removed in version 3.0.0. "
        "Use combine_images_robust() for better outlier rejection.",
        DeprecationWarning,
        stacklevel=2,
    )

    # Accept both 'hdu' and the legacy 'ext' keyword
    hdu = kwargs.get("hdu", kwargs.get("ext", 0))
    overwrite = kwargs.get("overwrite", False)
    output_dir = kwargs.get("output_dir", None)
    header_template = kwargs.get("header", None)

    base_header = fits.Header()

    # Handle in-memory arrays
    if isinstance(input_param, list) and all(
        isinstance(i, np.ndarray) for i in input_param
    ):
        logger.debug(
            "Processing %d in-memory NumPy arrays", len(input_param)
        )

        try:
            stacked_data, _, base_header = _load_and_stack_efficient(
                input_param,
                hdu=hdu,
                keys=kwargs.get("keys"),
                working_dtype=working_dtype,
                recursive=kwargs.get("recursive", False),
            )
        except Exception as e:
            logger.error("Failed to stack arrays: %s", e)
            return None

        if header_template:
            base_header = header_template.copy()
        add_history(
            base_header,
            f"Combined from {len(input_param)} in-memory arrays",
        )

    # Handle files
    else:
        if isinstance(input_param, str):
            try:
                files_to_process = select_files(
                    input_param,
                    keys=kwargs.get("keys"),
                    recursive=kwargs.get("recursive", False),
                )
            except Exception as e:
                logger.error("File selection failed: %s", e)
                return None
        else:
            files_to_process = input_param

        if not files_to_process:
            logger.warning("No files found or selected for combination")
            return None

        max_files = kwargs.get("max_files")
        if max_files and len(files_to_process) > max_files:
            files_to_process = files_to_process[:max_files]

        logger.debug("Found %d files to combine", len(files_to_process))

        try:
            stacked_data, _, base_header = _load_and_stack_efficient(
                files_to_process,
                hdu=hdu,
                keys=kwargs.get("keys"),
                recursive=kwargs.get("recursive", False),
            )
        except Exception as e:
            logger.error("Failed to load and stack files: %s", e)
            return None

        if header_template:
            base_header = header_template.copy()

        add_history(
            base_header, f"Combined from {len(files_to_process)} files"
        )
        base_header["NCOMBINE"] = (
            len(files_to_process), "Number of files combined"
        )

    def _combine_simple(data_stack: np.ndarray, operation: str) -> np.ndarray:
        """Perform simple combining without outlier rejection."""
        if operation == "median":
            return np.median(data_stack, axis=0)
        elif operation == "mean":
            return np.mean(data_stack, axis=0)
        else:
            raise ValueError(f"Unsupported operation: {operation}")

    # In-memory mode
    if filebase is None and output_dir is None:
        logger.debug("Operating in pure in-memory mode (no disk I/O)")
        try:
            if isinstance(operations, str):
                return _combine_simple(stacked_data, operations)
            else:
                return {
                    op: _combine_simple(stacked_data, op)
                    for op in operations
                }
        except Exception as e:
            logger.error("Error during in-memory combination: %s", e)
            return None

    # File output mode
    if output_dir is None:
        output_dir = Path(filebase).parent if filebase else Path(".")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ops = [operations] if isinstance(operations, str) else operations
    results = {}

    for op in ops:
        current_filebase = f"{filebase}_{op}" if len(ops) > 1 else filebase
        output_path = output_dir / f"{current_filebase}.fits"

        if output_path.exists() and not overwrite:
            logger.warning(
                "File exists and overwrite=False: %s", output_path
            )
            results[op] = output_path
            continue

        try:
            logger.debug("Performing '%s' combination...", op)
            combined_array = _combine_simple(stacked_data, op)

            op_header = base_header.copy()
            add_history(op_header, f"Combined using '{op}' operation")
            op_header["COMBMETH"] = (op, "Combining method")

            write_simple_fits(
                output_path, combined_array, op_header, overwrite=overwrite
            )
            results[op] = output_path

        except Exception as e:
            logger.error(
                "Failed to create combined image for operation '%s': %s",
                op, e,
            )
            results[op] = None

    return results[operations] if isinstance(operations, str) else results


# ============================================================================
# Module Exports
# ============================================================================

__all__ = [
    # Primary API
    "combine_images_robust",
    "create_master_frame",
    # Convenience wrappers
    "median_combine",
    "mean_combine",
    # Legacy API
    "combine_images",
]
